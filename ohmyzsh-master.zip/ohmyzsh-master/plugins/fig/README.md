# Fig plugin

This plugin sets up completion for [Fig](https://fig.io/).

To use it, add `fig` to the plugins array in your zshrc file:

```zsh
plugins=(... fig)
```
